import Foundation
class MyHTMLParser: NSObject, XMLParserDelegate {
    var elements: [[String: Any]] = []
    var currentElement: [String: Any]?
    
    func parseHTML(htmlString: String, forTags tags: [String]) {
        let data = htmlString.data(using: .utf8)!
        let parser = XMLParser(data: data)
        parser.delegate = self
        parser.parse()
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if attributeDict.isEmpty || !["p", "a" , "h1", "h1","h2" ,"h3" ,"h4" ,"h5"].contains(elementName) {
            return
        }
        currentElement = ["tag": elementName, "attrs": attributeDict.map { ["name": $0.key, "value": $0.value] }]
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if currentElement != nil && currentElement!["tag"] as! String == elementName {
            elements.append(currentElement!)
            currentElement = nil
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        // Do nothing
    }
    
    func parser(_ parser: XMLParser, parseErrorOccurred parseError: Error) {
        print("Error: \(parseError.localizedDescription)")
    }
}

let parser = MyHTMLParser()
let htmlString = "<html><head><title>Test</title></head><body><p class=\"paragraph\">This is a paragraph1.</p><a href=\"http://www.example.com\">Example Website</a> <p class=\"paragraph\">This is a paragraph2.</p> <p class=\"paragraph\">This is a paragraph4.</p><p class=\"paragraph\">This is a paragraph.</p><a href=\"http://www.google.com\">google  Website</a><a href=\"http://www.facebook.com\">facebook Website</a><h1 class=\"heading1 \">heading1</h1><h2 class=\"heading2 \">heading2</h2><h3 class=\"heading3 \">heading3</h3><h4 class=\"heading4 \">heading4</h4><h5 class=\"heading5 \">heading5</h5><h1 class=\"heading1 \">heading1</h1></body></html>"
parser.parseHTML(htmlString: htmlString, forTags: ["p", "a" , "h1","h2" ,"h3" ,"h4" ,"h5"])
for element in parser.elements {
   // print(element["tag"]!)
    for attr in element["attrs"] as! [[String: String]] {
        //print("\(attr["name"]!)=\"\(attr["value"]!)\"")
       //
        .print("\(attr["value"]!)")
        print("\(element["tag"]!)=\"\(attr["value"]!)\"")
        
    }
}

